Apache Avro™ is a data serialization system.

Learn more about Avro, please visit our website at:

  http://avro.apache.org/

To contribute to Avro, please read:

  https://cwiki.apache.org/confluence/display/AVRO/How+To+Contribute

For LICENSE and NOTICE information for the python3 implementation, see:
* avro/LICENSE
* avro/NOTICE
